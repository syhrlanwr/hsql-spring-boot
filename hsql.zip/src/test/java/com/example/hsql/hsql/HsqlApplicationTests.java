package com.example.hsql.hsql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HsqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
