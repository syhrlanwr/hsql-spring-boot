package com.example.hsql.hsql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HsqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(HsqlApplication.class, args);
	}

}
